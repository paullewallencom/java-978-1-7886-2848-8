module data.processor {
    requires vehicle.models;

    exports carprocessor;
}