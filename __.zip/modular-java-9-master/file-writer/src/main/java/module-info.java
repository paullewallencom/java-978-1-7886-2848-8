module file.writer {
    requires commons.csv;
    requires vehicle.models;
    exports csv;
}