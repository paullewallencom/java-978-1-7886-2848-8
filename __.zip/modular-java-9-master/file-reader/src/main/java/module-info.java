module file.reader {
    requires vehicle.models;
    requires json.simple;

    exports json;
}