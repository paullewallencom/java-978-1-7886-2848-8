module bootstrap {
    requires vehicle.models;
    requires data.processor;
    requires file.reader;
    requires file.writer;
    requires json.simple;
}