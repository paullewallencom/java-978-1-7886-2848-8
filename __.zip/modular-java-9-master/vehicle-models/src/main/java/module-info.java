module vehicle.models {
    exports car;
}